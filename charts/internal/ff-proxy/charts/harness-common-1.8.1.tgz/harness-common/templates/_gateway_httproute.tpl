{{/*
USAGE:
{{- include "harnesscommon.v2.renderHTTPRoute" (dict "ctx" $) }}
or
{{- include "harnesscommon.v2.renderHTTPRoute" (dict "gateway" .Values.other.gateway "ctx" $) }}
*/}}

{{/*
Compute the deterministic name of the HTTPRouteFilter (Envoy Gateway urlRewrite)
for a given route + rendered path. This MUST be the single source of truth: the
per-rule `extensionRef.name` (the reference) and the `HTTPRouteFilter.metadata.name`
(the target) are emitted from separate blocks, so both call this helper to guarantee
the reference can never point at a name that isn't emitted.

USAGE:
{{ include "harnesscommon.v2.httpRouteFilterName" (dict "routeName" $chunkRouteName "path" $renderedPath) }}
where $renderedPath is the already-rendered path string.
*/}}
{{- define "harnesscommon.v2.httpRouteFilterName" -}}
{{- $routeName := .routeName -}}
{{- $renderedPath := .path -}}
{{- $step1 := $renderedPath | trimPrefix "/" -}}
{{- $step2 := regexReplaceAll "[^a-zA-Z0-9/]" $step1 "" -}}
{{- $step3 := regexReplaceAll "/" $step2 "-" -}}
{{- $step4 := regexReplaceAll "-+" $step3 "-" -}}
{{- $pathSlugFull := $step4 | trimSuffix "-" | lower -}}
{{- $shortHash := sha1sum $renderedPath | trunc 6 -}}
{{- $maxPathLen := sub 253 (add (len $routeName) 8) | int -}}
{{- $pathSlug := "" -}}
{{- if $pathSlugFull -}}
  {{- if gt (len $pathSlugFull) $maxPathLen -}}
    {{- $pathSlug = trunc $maxPathLen $pathSlugFull | trimSuffix "-" -}}
  {{- else -}}
    {{- $pathSlug = $pathSlugFull -}}
  {{- end -}}
{{- end -}}
{{- if $pathSlug -}}
{{- cat $routeName "-" $pathSlug "-" $shortHash | nospace -}}
{{- else -}}
{{- cat $routeName "-" $shortHash | nospace -}}
{{- end -}}
{{- end -}}

{{- define "harnesscommon.v2.renderHTTPRoute" }}
{{- $ := .ctx }}
{{- $ingress := $.Values.ingress }}
{{- if .ingress -}}
    {{- $ingress = .ingress }}
{{- end }}
{{- if and (dig "gatewayAPI" "enabled" false $.Values.global) (dig "ingress" "enabled" false $.Values.global) -}}
{{- range $index, $object := $ingress.objects }}
{{- $routeName := dig "name" ((cat (coalesce $ingress.name $.Values.nameOverride $.Chart.Name | trunc 63 | trimSuffix "-") "-" $index) | nospace) $object }}
{{- $objectAnnotations := dig "annotations" dict $object }}
{{- /* Print migration suggestions if nginx annotations are detected */}}
{{- if $objectAnnotations }}
{{- include "harnesscommon.v2.printGatewayAPIMigrationSuggestions" (dict "ctx" $ "routeName" $routeName "annotations" $objectAnnotations) }}
{{- end }}
{{- /* Gateway API limits HTTPRoute to 16 rules. Split into chunks. */}}
{{- $maxRules := 16 }}
{{- $paths := $object.paths }}
{{- $numPaths := len $paths }}
{{- $numChunks := add1 (div (sub $numPaths 1) $maxRules) }}
{{- range $chunkIdx := until (int $numChunks) }}
{{- $start := mul $chunkIdx $maxRules }}
{{- $end := min (add $start $maxRules) $numPaths }}
{{- $chunkPaths := slice $paths (int $start) (int $end) }}
{{- $chunkRouteName := $routeName }}
{{- if gt $numChunks 1 }}
{{- $chunkRouteName = printf "%s-part-%d" $routeName $chunkIdx }}
{{- end }}
---
apiVersion: gateway.networking.k8s.io/v1
kind: HTTPRoute
metadata:
  name: {{ $chunkRouteName }}
  namespace: {{ $.Release.Namespace }}
  {{- if $.Values.global.commonLabels }}
  labels:
    {{- include "harnesscommon.tplvalues.render" ( dict "value" $.Values.global.commonLabels "context" $ ) | nindent 4 }}
  {{- end }}
  annotations:
    {{- /* The usual Ingress annotation to influence nginx location rules won't apply here, so we will
    not render $object.annotations in HTTPRoute objects */}}
    {{- if $ingress.annotations }}
    {{- include "harnesscommon.tplvalues.render" (dict "value" $ingress.annotations "context" $) | nindent 4 }}
    {{- end }}
    {{- if $.Values.global.commonAnnotations }}
    {{- include "harnesscommon.tplvalues.render" ( dict "value" $.Values.global.commonAnnotations "context" $ ) | nindent 4 }}
    {{- end }}
    {{- if $.Values.global.ingress.objects.annotations }}
    {{- include "harnesscommon.tplvalues.render" (dict "value" $.Values.global.ingress.objects.annotations "context" $) | nindent 4 }}
    {{- end }}
    {{- range $ca := $object.conditionalAnnotations }}
        {{- $condition := "false" }}
        {{- if hasKey $ca "condition" }}
            {{- $condition = include "harnesscommon.utils.getValueFromKey" (dict "key" $ca.condition "context" $ ) }}
        {{- end }}
        {{- if eq $condition "true" }}
            {{- include "harnesscommon.tplvalues.render" (dict "value" $ca.annotations "context" $) | nindent 4 }}
        {{- end }}
    {{- end }}
spec:
  {{- if $.Values.global.gatewayAPI.parentRef }}
  # Default parentRef from global config
  {{- $parentRefNamespace := $.Values.global.gatewayAPI.parentRef.namespace | default $.Release.Namespace }}
  parentRefs:
    - name: {{ include "harnesscommon.tplvalues.render" ( dict "value" $.Values.global.gatewayAPI.parentRef.name "context" $) }}
      {{- if $parentRefNamespace }}
      namespace: {{ include "harnesscommon.tplvalues.render" ( dict "value" $parentRefNamespace "context" $) }}
      {{- end }}
      {{- if $.Values.global.gatewayAPI.parentRef.sectionName }}
      sectionName: {{ $.Values.global.gatewayAPI.parentRef.sectionName }}
      {{- end }}
      {{- if $.Values.global.gatewayAPI.parentRef.port }}
      port: {{ $.Values.global.gatewayAPI.parentRef.port }}
      {{- end }}
  {{- end }}
  {{- /* Gateway API hostname validation rejects bare "*"; valid wildcard form is "*.example.com".
  Build a filtered hostname list, dropping bare "*". If the resulting list is empty (or
  disableHostInIngress is true), omit the hostnames field so the HTTPRoute inherits from the
  parent Gateway listener. */}}
  {{- $hostnameList := list }}
  {{- if not $.Values.global.ingress.disableHostInIngress }}
    {{- range $.Values.global.ingress.hosts }}
      {{- if ne . "*" }}
        {{- $hostnameList = append $hostnameList . }}
      {{- end }}
    {{- end }}
    {{- $globalHttpRoute := dig "httpRoute" dict $.Values.global.gatewayAPI }}
    {{- if $globalHttpRoute.additionalHostnames }}
      {{- range $hostname := $globalHttpRoute.additionalHostnames }}
        {{- if ne $hostname "*" }}
          {{- $hostnameList = append $hostnameList $hostname }}
        {{- end }}
      {{- end }}
    {{- end }}
    {{- $perRouteHttpRoute := dig "gatewayAPI" dict $object }}
    {{- if $perRouteHttpRoute.additionalHostnames }}
      {{- range $hostname := $perRouteHttpRoute.additionalHostnames }}
        {{- if ne $hostname "*" }}
          {{- $hostnameList = append $hostnameList $hostname }}
        {{- end }}
      {{- end }}
    {{- end }}
  {{- end }}
  {{- if $hostnameList }}
  hostnames:
    {{- range $hostname := $hostnameList }}
    - {{ $hostname | quote }}
    {{- end }}
  {{- end }}
  rules:
    {{- range $idx := $chunkPaths }}
    {{- $serviceName := dig "backend" "service" "name" $.Chart.Name $idx }}
    {{- /* Gateway API routes through the Service (envoy -> Service ClusterIP), so
    backendRef.port MUST be the Service's spec.ports[].port -- NOT the nginx
    backend.service.port, which is the pod/targetPort that nginx connects to
    directly via endpoints. Using the targetPort here yields
    ResolvedRefs=False "TCP Port <n> not found on Service" and 500s the route.
    Precedence: per-path gatewayAPI.backend.service.port > per-object
    gatewayAPI.backend.service.port > chart service.port (the Service's declared port). */}}
    {{- $servicePort := dig "gatewayAPI" "backend" "service" "port" (dig "gatewayAPI" "backend" "service" "port" $.Values.service.port $object) $idx }}
    {{- $globalHttpRoute := dig "httpRoute" dict $.Values.global.gatewayAPI }}
    {{- $perRouteHttpRoute := dig "gatewayAPI" dict $object }}
    {{- $hasRewriteTarget := and $objectAnnotations (hasKey $objectAnnotations "nginx.ingress.kubernetes.io/rewrite-target") }}
    {{- $hasUpstreamVhost := or $globalHttpRoute.upstreamHostOverride $perRouteHttpRoute.upstreamHostOverride }}
    {{- $hasRequestHeaders := or $globalHttpRoute.requestHeaders $perRouteHttpRoute.requestHeaders }}
    {{- $hasResponseHeaders := or $globalHttpRoute.responseHeaders $perRouteHttpRoute.responseHeaders }}
    {{- $needsFilters := or $hasRewriteTarget $hasUpstreamVhost $hasRequestHeaders $hasResponseHeaders }}
    - matches:
        - path:
            type: RegularExpression
            value: {{ include "harnesscommon.tplvalues.render" ( dict "value" $idx.path "context" $) }}
      {{- if $needsFilters }}
      filters:
        {{- /* Request Header Modifier - handles upstreamHostOverride and custom headers */}}
        {{- $requestHeaderModifier := dict }}
        {{- $hasRequestModifier := false }}
        {{- /* Upstream host override (nginx upstream-vhost equivalent) */}}
        {{- $upstreamHost := "" }}
        {{- if $perRouteHttpRoute.upstreamHostOverride }}
          {{- $upstreamHost = $perRouteHttpRoute.upstreamHostOverride }}
        {{- else if $globalHttpRoute.upstreamHostOverride }}
          {{- $upstreamHost = $globalHttpRoute.upstreamHostOverride }}
        {{- end }}
        {{- if $upstreamHost }}
          {{- $hasRequestModifier = true }}
          {{- $_ := set $requestHeaderModifier "set" (list (dict "name" "Host" "value" $upstreamHost)) }}
        {{- end }}
        {{- /* Custom request headers (set/add/remove) */}}
        {{- $reqHeaders := dict }}
        {{- if $globalHttpRoute.requestHeaders }}
          {{- $reqHeaders = $globalHttpRoute.requestHeaders }}
        {{- end }}
        {{- if $perRouteHttpRoute.requestHeaders }}
          {{- $reqHeaders = $perRouteHttpRoute.requestHeaders }}
        {{- end }}
        {{- if or $reqHeaders.set $reqHeaders.add $reqHeaders.remove }}
          {{- $hasRequestModifier = true }}
          {{- if $reqHeaders.set }}
            {{- if $upstreamHost }}
              {{- /* Merge with existing Host header */}}
              {{- $existingSet := get $requestHeaderModifier "set" }}
              {{- range $header := $reqHeaders.set }}
                {{- $existingSet = append $existingSet $header }}
              {{- end }}
              {{- $_ := set $requestHeaderModifier "set" $existingSet }}
            {{- else }}
              {{- $_ := set $requestHeaderModifier "set" $reqHeaders.set }}
            {{- end }}
          {{- end }}
          {{- if $reqHeaders.add }}
            {{- $_ := set $requestHeaderModifier "add" $reqHeaders.add }}
          {{- end }}
          {{- if $reqHeaders.remove }}
            {{- $_ := set $requestHeaderModifier "remove" $reqHeaders.remove }}
          {{- end }}
        {{- end }}
        {{- if $hasRequestModifier }}
        - type: RequestHeaderModifier
          requestHeaderModifier:
            {{- if $requestHeaderModifier.set }}
            set:
              {{- range $header := $requestHeaderModifier.set }}
              - name: {{ $header.name | quote }}
                value: {{ $header.value | quote }}
              {{- end }}
            {{- end }}
            {{- if $requestHeaderModifier.add }}
            add:
              {{- range $header := $requestHeaderModifier.add }}
              - name: {{ $header.name | quote }}
                value: {{ $header.value | quote }}
              {{- end }}
            {{- end }}
            {{- if $requestHeaderModifier.remove }}
            remove:
              {{- range $headerName := $requestHeaderModifier.remove }}
              - {{ $headerName | quote }}
              {{- end }}
            {{- end }}
        {{- end }}
        {{- /* Response Header Modifier */}}
        {{- $respHeaders := dict }}
        {{- if $globalHttpRoute.responseHeaders }}
          {{- $respHeaders = $globalHttpRoute.responseHeaders }}
        {{- end }}
        {{- if $perRouteHttpRoute.responseHeaders }}
          {{- $respHeaders = $perRouteHttpRoute.responseHeaders }}
        {{- end }}
        {{- if or $respHeaders.set $respHeaders.add $respHeaders.remove }}
        - type: ResponseHeaderModifier
          responseHeaderModifier:
            {{- if $respHeaders.set }}
            set:
              {{- range $header := $respHeaders.set }}
              - name: {{ $header.name | quote }}
                value: {{ $header.value | quote }}
              {{- end }}
            {{- end }}
            {{- if $respHeaders.add }}
            add:
              {{- range $header := $respHeaders.add }}
              - name: {{ $header.name | quote }}
                value: {{ $header.value | quote }}
              {{- end }}
            {{- end }}
            {{- if $respHeaders.remove }}
            remove:
              {{- range $headerName := $respHeaders.remove }}
              - {{ $headerName | quote }}
              {{- end }}
            {{- end }}
        {{- end }}
        {{- /* URL Rewrite filter. The extensionRef name is computed by the shared
        helper so it always matches the emitted HTTPRouteFilter below (same predicate,
        same computed name) -- never a dangling reference. */}}
        {{- if $hasRewriteTarget }}
        {{- $renderedPath := include "harnesscommon.tplvalues.render" ( dict "value" $idx.path "context" $) }}
        - type: ExtensionRef
          extensionRef:
            group: gateway.envoyproxy.io
            kind: HTTPRouteFilter
            name: {{ include "harnesscommon.v2.httpRouteFilterName" (dict "routeName" $chunkRouteName "path" $renderedPath) }}
        {{- end }}
      {{- end }}
      # Backend services
      backendRefs:
        - name: {{ $serviceName }}
          port: {{ $servicePort }}
      {{- if and $objectAnnotations (hasKey $objectAnnotations "nginx.ingress.kubernetes.io/proxy-read-timeout") }}
      # Timeouts for this rule
      timeouts:
        {{- /* Add timeouts if the nginx annotation was set. Not ideal, as these settings are not equivalent.
        TODO: Improve? */}}
        backendRequest: {{ printf "%s%s" (get $objectAnnotations "nginx.ingress.kubernetes.io/proxy-read-timeout") "s" }}
      {{- end }}
    {{- end }}
{{- if and $objectAnnotations (hasKey $objectAnnotations "nginx.ingress.kubernetes.io/rewrite-target") }}
{{- /* Track filter names already emitted for this object so that duplicate paths
(which slug + hash to an identical name) don't produce two HTTPRouteFilter resources
with the same id, which would fail rendering. */}}
{{- $seenFilterNames := dict }}
{{- range $idx := $chunkPaths }}
{{- $renderedPath := include "harnesscommon.tplvalues.render" ( dict "value" $idx.path "context" $) }}
{{- $filterName := include "harnesscommon.v2.httpRouteFilterName" (dict "routeName" $chunkRouteName "path" $renderedPath) }}
{{- if not (hasKey $seenFilterNames $filterName) }}
{{- $_ := set $seenFilterNames $filterName true }}
---
apiVersion: gateway.envoyproxy.io/v1alpha1
kind: HTTPRouteFilter
metadata:
  name: {{ $filterName }}
  namespace: {{ $.Release.Namespace }}
  {{- if $.Values.global.commonLabels }}
  labels:
    {{- include "harnesscommon.tplvalues.render" ( dict "value" $.Values.global.commonLabels "context" $ ) | nindent 4 }}
  {{- end }}
  annotations:
    {{- /* The usual Ingress annotation to influence nginx location rules won't apply here, so we will
    not render $object.annotations in HTTPRoute objects */}}
    {{- if $ingress.annotations }}
    {{- include "harnesscommon.tplvalues.render" (dict "value" $ingress.annotations "context" $) | nindent 4 }}
    {{- end }}
    {{- if $.Values.global.commonAnnotations }}
    {{- include "harnesscommon.tplvalues.render" ( dict "value" $.Values.global.commonAnnotations "context" $ ) | nindent 4 }}
    {{- end }}
    {{- if $.Values.global.ingress.objects.annotations }}
    {{- include "harnesscommon.tplvalues.render" (dict "value" $.Values.global.ingress.objects.annotations "context" $) | nindent 4 }}
    {{- end }}
    {{- range $ca := $object.conditionalAnnotations }}
        {{- $condition := "false" }}
        {{- if hasKey $ca "condition" }}
            {{- $condition = include "harnesscommon.utils.getValueFromKey" (dict "key" $ca.condition "context" $ ) }}
        {{- end }}
        {{- if eq $condition "true" }}
            {{- include "harnesscommon.tplvalues.render" (dict "value" $ca.annotations "context" $) | nindent 4 }}
        {{- end }}
    {{- end }}
spec:
  urlRewrite:
    path:
      type: ReplaceRegexMatch
      replaceRegexMatch:
        pattern: {{ include "harnesscommon.tplvalues.render" ( dict "value" $idx.path "context" $) }}
        substitution: {{ include "harnesscommon.tplvalues.render" ( dict "value" ( regexReplaceAll "\\$" (get $objectAnnotations "nginx.ingress.kubernetes.io/rewrite-target") "\\" ) "context" $) }}
{{- end }} {{/* If filter name not already emitted */}}
{{- end }} {{/* Range over chunk paths */}}
{{- end }} {{/* If to create HTTPRouteFilter */}}
{{- end }} {{/* Range over chunks */}}
{{- end }} {{/* Range over all the ingress keys */}}
{{- end }} {{/* if gateway / ingress enabled */}}
{{- end }} {{/* define */}}
