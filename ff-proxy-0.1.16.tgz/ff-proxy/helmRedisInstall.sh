#!/bin/bash

"echo installing redis"

helm upgrade -i --namespace ff-proxy-wf --create-namespace \
    sharefile oci://registry-1.docker.io/bitnamicharts/redis \
    --set auth.enabled=false \
    --set replica.autoscaling.enabled=true \
    --set replica.autoscaling.minReplicas=1 \
    --set replica.autoscaling.maxReplicas=2 \
    --set resources.requests.cpu="500m" \
