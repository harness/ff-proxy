#!/bin/bash
echo "uninstalling redis"

helm uninstall sharefile --namespace ff-proxy
